"""
Nine Men's Morris - Curriculum Manager
Handles phased training with automatic progression
"""

import os
import json
import time
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Tuple
from collections import deque
from enum import IntEnum
import numpy as np


class Phase(IntEnum):
    """Training phases."""
    PHASE_1_RANDOM = 1       # Learn basics vs random
    PHASE_2_MINIMAX_EASY = 2 # Beat minimax D1-D2
    PHASE_3_REDUCED_REWARDS = 3  # Less reward shaping vs D2-D3
    PHASE_4_SPARSE_REWARDS = 4   # Win/loss only vs D3-D4
    PHASE_5_SELF_PLAY = 5    # Refinement via self-play
    COMPLETED = 6


@dataclass
class PhaseConfig:
    """Configuration for a single training phase."""
    phase: Phase
    description: str
    
    # Opponent settings
    opponent_type: str  # 'random', 'minimax', 'self'
    minimax_start_depth: int = 1
    minimax_max_depth: int = 1
    
    # Learning rate
    lr_start: float = 3e-4
    lr_end: float = 1e-4
    
    # Reward multipliers (applied to base rewards)
    win_reward_base: float = 1.0
    win_reward_speed_bonus: float = 1.0  # Extra for fast wins
    loss_reward: float = -1.0
    draw_penalty: float = -0.5
    
    # Shaping reward multiplier (0.0 = no shaping, 1.0 = full shaping)
    shaping_multiplier: float = 1.0
    
    # Base shaping rewards (multiplied by shaping_multiplier)
    mill_reward: float = 0.3
    enemy_mill_penalty: float = -0.3
    block_mill_reward: float = 0.2
    double_mill_reward: float = 0.5
    double_mill_extra_reward: float = 0.8
    setup_capture_reward: float = 0.2
    
    # Graduation criteria
    win_rate_threshold: float = 0.95
    min_games_for_graduation: int = 500
    minimax_depth_to_beat: int = 0  # 0 means not applicable
    no_loss_streak_required: int = 0  # 0 means not required
    
    # Duration limits
    max_episodes: int = 0  # 0 means no limit


# Define all phases
PHASE_CONFIGS = {
    Phase.PHASE_1_RANDOM: PhaseConfig(
        phase=Phase.PHASE_1_RANDOM,
        description="Learning basics against random opponent",
        opponent_type='random',
        lr_start=3e-4,
        lr_end=1e-4,
        win_reward_base=2.0,       # INCREASED from 1.0
        win_reward_speed_bonus=1.0,
        loss_reward=-2.0,          # INCREASED magnitude
        draw_penalty=-0.8,         # Stronger draw penalty
        shaping_multiplier=0.2,    # REDUCED from 1.0 - less shaping!
        mill_reward=0.3,
        enemy_mill_penalty=-0.3,
        block_mill_reward=0.2,
        double_mill_reward=0.5,
        double_mill_extra_reward=0.8,
        setup_capture_reward=0.2,
        win_rate_threshold=0.92,   # Slightly lower threshold
        min_games_for_graduation=1000,
    ),
    
    Phase.PHASE_2_MINIMAX_EASY: PhaseConfig(
        phase=Phase.PHASE_2_MINIMAX_EASY,
        description="Learning strategy against weak minimax (D1-D2)",
        opponent_type='minimax',
        minimax_start_depth=1,
        minimax_max_depth=2,
        lr_start=1e-4,
        lr_end=5e-5,
        win_reward_base=2.0,       # Strong terminal signal
        win_reward_speed_bonus=1.0,
        loss_reward=-2.0,
        draw_penalty=-0.5,
        shaping_multiplier=0.5,    # Moderate shaping
        mill_reward=0.3,
        enemy_mill_penalty=-0.3,
        block_mill_reward=0.2,
        double_mill_reward=0.5,
        double_mill_extra_reward=0.8,
        setup_capture_reward=0.2,
        win_rate_threshold=0.80,   # 80% to pass
        min_games_for_graduation=500,
        minimax_depth_to_beat=2,
    ),
    
    Phase.PHASE_3_REDUCED_REWARDS: PhaseConfig(
        phase=Phase.PHASE_3_REDUCED_REWARDS,
        description="Reducing reward dependency against minimax (D2-D3)",
        opponent_type='minimax',
        minimax_start_depth=2,
        minimax_max_depth=3,
        lr_start=5e-5,
        lr_end=1e-5,
        win_reward_base=1.0,
        win_reward_speed_bonus=1.0,
        loss_reward=-1.5,
        draw_penalty=-0.5,
        shaping_multiplier=0.5,  # Half the shaping rewards
        mill_reward=0.3,
        enemy_mill_penalty=-0.3,
        block_mill_reward=0.2,
        double_mill_reward=0.5,
        double_mill_extra_reward=0.8,
        setup_capture_reward=0.2,
        win_rate_threshold=0.75,
        min_games_for_graduation=500,
        minimax_depth_to_beat=3,
    ),
    
    Phase.PHASE_4_SPARSE_REWARDS: PhaseConfig(
        phase=Phase.PHASE_4_SPARSE_REWARDS,
        description="Sparse rewards only against minimax (D3-D4)",
        opponent_type='minimax',
        minimax_start_depth=3,
        minimax_max_depth=4,
        lr_start=1e-5,
        lr_end=5e-6,
        win_reward_base=1.0,
        win_reward_speed_bonus=1.0,
        loss_reward=-1.5,
        draw_penalty=-0.3,
        shaping_multiplier=0.0,  # No shaping rewards!
        win_rate_threshold=0.70,
        min_games_for_graduation=500,
        minimax_depth_to_beat=4,
    ),
    
    Phase.PHASE_5_SELF_PLAY: PhaseConfig(
        phase=Phase.PHASE_5_SELF_PLAY,
        description="Self-play refinement",
        opponent_type='self',
        lr_start=5e-6,
        lr_end=1e-6,
        win_reward_base=1.0,
        win_reward_speed_bonus=0.5,  # Less speed bonus in self-play
        loss_reward=-1.0,
        draw_penalty=-0.3,
        shaping_multiplier=0.0,  # No shaping
        max_episodes=1_000_000,  # Run for fixed duration
    ),
}


@dataclass
class PhaseStats:
    """Statistics for current phase."""
    phase: Phase
    episodes_in_phase: int = 0
    total_games: int = 0
    wins: int = 0
    losses: int = 0
    draws: int = 0
    current_minimax_depth: int = 1
    best_win_rate: float = 0.0
    games_since_last_loss: int = 0
    phase_start_time: float = field(default_factory=time.time)
    
    # Rolling stats - must be >= max graduation requirement
    recent_results: deque = field(default_factory=lambda: deque(maxlen=2000))
    
    def add_result(self, result: str):
        """Add game result: 'win', 'loss', or 'draw'."""
        self.total_games += 1
        self.recent_results.append(result)
        
        if result == 'win':
            self.wins += 1
            self.games_since_last_loss += 1
        elif result == 'loss':
            self.losses += 1
            self.games_since_last_loss = 0
        else:  # draw
            self.draws += 1
            self.games_since_last_loss += 1
        
        # Update best win rate
        if len(self.recent_results) >= 100:
            wr = self.get_win_rate()
            if wr > self.best_win_rate:
                self.best_win_rate = wr
    
    def get_win_rate(self) -> float:
        """Get win rate from recent games."""
        if not self.recent_results:
            return 0.0
        wins = sum(1 for r in self.recent_results if r == 'win')
        return wins / len(self.recent_results)
    
    def get_draw_rate(self) -> float:
        """Get draw rate from recent games."""
        if not self.recent_results:
            return 0.0
        draws = sum(1 for r in self.recent_results if r == 'draw')
        return draws / len(self.recent_results)
    
    def get_loss_rate(self) -> float:
        """Get loss rate from recent games."""
        if not self.recent_results:
            return 0.0
        losses = sum(1 for r in self.recent_results if r == 'loss')
        return losses / len(self.recent_results)


class CurriculumManager:
    """Manages phased curriculum training."""
    
    def __init__(self, start_phase: Phase = Phase.PHASE_1_RANDOM, save_dir: str = "curriculum"):
        self.current_phase = start_phase
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)
        
        self.stats = PhaseStats(phase=start_phase)
        self.phase_history: List[Dict] = []
        self.total_episodes = 0
        
        # Callbacks
        self.on_phase_change_callbacks = []
    
    def get_config(self) -> PhaseConfig:
        """Get current phase configuration."""
        return PHASE_CONFIGS[self.current_phase]
    
    def get_learning_rate(self) -> float:
        """Get current learning rate based on phase progress."""
        config = self.get_config()
        
        # Linear interpolation based on progress in phase
        if config.max_episodes > 0:
            progress = min(1.0, self.stats.episodes_in_phase / config.max_episodes)
        else:
            # Use win rate progress toward threshold
            wr = self.stats.get_win_rate()
            progress = min(1.0, wr / config.win_rate_threshold) if config.win_rate_threshold > 0 else 0.5
        
        lr = config.lr_start + progress * (config.lr_end - config.lr_start)
        return lr
    
    def get_minimax_depth(self) -> int:
        """Get current minimax depth for the phase."""
        config = self.get_config()
        if config.opponent_type != 'minimax':
            return 1
        return self.stats.current_minimax_depth
    
    def get_reward_config(self) -> Dict[str, float]:
        """Get current reward configuration."""
        config = self.get_config()
        mult = config.shaping_multiplier
        
        return {
            'win_reward_base': config.win_reward_base,
            'win_reward_speed_bonus': config.win_reward_speed_bonus,
            'loss_reward': config.loss_reward,
            'draw_penalty': config.draw_penalty,
            'mill_reward': config.mill_reward * mult,
            'enemy_mill_penalty': config.enemy_mill_penalty * mult,
            'block_mill_reward': config.block_mill_reward * mult,
            'double_mill_reward': config.double_mill_reward * mult,
            'double_mill_extra_reward': config.double_mill_extra_reward * mult,
            'setup_capture_reward': config.setup_capture_reward * mult,
        }
    
    def add_game_result(self, result: float, is_self_play: bool = False):
        """
        Add a game result.
        result > 0.5 = win, result < -0.5 = loss, else = draw
        """
        self.total_episodes += 1
        self.stats.episodes_in_phase += 1
        
        # Don't count self-play results for graduation (always 50% win rate)
        if is_self_play:
            return
        
        if result > 0.5:
            self.stats.add_result('win')
        elif result < -0.5:
            self.stats.add_result('loss')
        else:
            self.stats.add_result('draw')
    
    def should_graduate(self) -> bool:
        """Check if ready to move to next phase."""
        if self.current_phase == Phase.COMPLETED:
            return False
        
        config = self.get_config()
        stats = self.stats
        
        # Check minimum games
        if len(stats.recent_results) < config.min_games_for_graduation:
            return False
        
        # Check max episodes (for self-play phase)
        if config.max_episodes > 0 and stats.episodes_in_phase >= config.max_episodes:
            return True
        
        # Check win rate threshold
        win_rate = stats.get_win_rate()
        if win_rate < config.win_rate_threshold:
            return False
        
        # For minimax phases: must be at target depth with good win rate
        if config.minimax_depth_to_beat > 0:
            if stats.current_minimax_depth < config.minimax_depth_to_beat:
                return False  # Haven't reached target depth yet
        
        # Check no-loss streak requirement
        if config.no_loss_streak_required > 0:
            if stats.games_since_last_loss < config.no_loss_streak_required:
                return False
        
        return True
    
    def graduate(self) -> bool:
        """Move to next phase. Returns True if graduated, False if already completed."""
        if self.current_phase == Phase.COMPLETED:
            return False
        
        # Save phase history
        self.phase_history.append({
            'phase': int(self.current_phase),
            'episodes': self.stats.episodes_in_phase,
            'total_games': self.stats.total_games,
            'wins': self.stats.wins,
            'losses': self.stats.losses,
            'draws': self.stats.draws,
            'best_win_rate': self.stats.best_win_rate,
            'final_minimax_depth': self.stats.current_minimax_depth,
            'duration_seconds': time.time() - self.stats.phase_start_time,
        })
        
        old_phase = self.current_phase
        
        # Move to next phase
        if self.current_phase == Phase.PHASE_5_SELF_PLAY:
            self.current_phase = Phase.COMPLETED
        else:
            self.current_phase = Phase(int(self.current_phase) + 1)
        
        # Reset stats for new phase
        new_config = PHASE_CONFIGS.get(self.current_phase)
        self.stats = PhaseStats(
            phase=self.current_phase,
            current_minimax_depth=new_config.minimax_start_depth if new_config else 1
        )
        
        # Notify callbacks
        for callback in self.on_phase_change_callbacks:
            callback(old_phase, self.current_phase)
        
        print(f"\n{'='*60}")
        print(f"🎓 GRADUATED from Phase {int(old_phase)} to Phase {int(self.current_phase)}!")
        if new_config:
            print(f"   {new_config.description}")
        print(f"{'='*60}\n")
        
        self.save_state()
        return True
    
    def check_and_graduate(self) -> bool:
        """Check graduation criteria and graduate if met."""
        if self.current_phase == Phase.COMPLETED:
            return False
        
        # First, check if we should promote minimax depth (for minimax phases)
        config = self.get_config()
        if config.opponent_type == 'minimax':
            self._check_depth_promotion()
        
        # Now check graduation
        if self.should_graduate():
            return self.graduate()
        return False
    
    def _check_depth_promotion(self):
        """Check if we should increase minimax depth."""
        config = self.get_config()
        stats = self.stats
        
        # Need enough games and high win rate to promote
        if len(stats.recent_results) < 100:
            return
        
        win_rate = stats.get_win_rate()
        current_depth = stats.current_minimax_depth
        
        # Promote if winning 75%+ at current depth
        if win_rate >= 0.75 and current_depth < config.minimax_max_depth:
            new_depth = current_depth + 1
            stats.current_minimax_depth = new_depth
            stats.recent_results.clear()  # Reset for new depth
            stats.wins = 0
            stats.losses = 0
            stats.draws = 0
            print(f"📈 Promoted to minimax depth {new_depth}! (was {win_rate:.0%} vs D{current_depth})")
    
    def save_state(self, path: Optional[str] = None):
        """Save curriculum state to file."""
        if path is None:
            path = os.path.join(self.save_dir, "curriculum_state.json")
        
        state = {
            'current_phase': int(self.current_phase),
            'total_episodes': self.total_episodes,
            'stats': {
                'phase': int(self.stats.phase),
                'episodes_in_phase': self.stats.episodes_in_phase,
                'total_games': self.stats.total_games,
                'wins': self.stats.wins,
                'losses': self.stats.losses,
                'draws': self.stats.draws,
                'current_minimax_depth': self.stats.current_minimax_depth,
                'best_win_rate': self.stats.best_win_rate,
                'games_since_last_loss': self.stats.games_since_last_loss,
            },
            'phase_history': self.phase_history,
        }
        
        with open(path, 'w') as f:
            json.dump(state, f, indent=2)
    
    def load_state(self, path: Optional[str] = None) -> bool:
        """Load curriculum state from file. Returns True if loaded successfully."""
        if path is None:
            path = os.path.join(self.save_dir, "curriculum_state.json")
        
        if not os.path.exists(path):
            return False
        
        try:
            with open(path, 'r') as f:
                state = json.load(f)
            
            self.current_phase = Phase(state['current_phase'])
            self.total_episodes = state['total_episodes']
            self.phase_history = state.get('phase_history', [])
            
            stats_data = state['stats']
            self.stats = PhaseStats(
                phase=Phase(stats_data['phase']),
                episodes_in_phase=stats_data['episodes_in_phase'],
                total_games=stats_data['total_games'],
                wins=stats_data['wins'],
                losses=stats_data['losses'],
                draws=stats_data['draws'],
                current_minimax_depth=stats_data['current_minimax_depth'],
                best_win_rate=stats_data['best_win_rate'],
                games_since_last_loss=stats_data['games_since_last_loss'],
            )
            
            print(f"✓ Loaded curriculum state: Phase {int(self.current_phase)}, {self.total_episodes} total episodes")
            return True
        except Exception as e:
            print(f"✗ Failed to load curriculum state: {e}")
            return False
    
    def get_status_string(self) -> str:
        """Get a status string for logging."""
        config = self.get_config()
        stats = self.stats
        
        wr = stats.get_win_rate()
        lr = stats.get_loss_rate()
        
        parts = [
            f"Phase {int(self.current_phase)}/{int(Phase.PHASE_5_SELF_PLAY)}",
            f"WR:{wr:.0%} LR:{lr:.0%}",
        ]
        
        if config.opponent_type == 'minimax':
            depth_str = f"D{stats.current_minimax_depth}"
            if config.minimax_depth_to_beat > 0:
                depth_str += f"→D{config.minimax_depth_to_beat}"
            parts.append(depth_str)
        
        # Show what's needed to graduate
        needs = []
        if wr < config.win_rate_threshold:
            needs.append(f"WR≥{config.win_rate_threshold:.0%}")
        if config.minimax_depth_to_beat > 0 and stats.current_minimax_depth < config.minimax_depth_to_beat:
            needs.append(f"reach D{config.minimax_depth_to_beat}")
        if len(stats.recent_results) < config.min_games_for_graduation:
            needs.append(f"N≥{config.min_games_for_graduation}")
        
        if needs:
            parts.append(f"Need: {', '.join(needs)}")
        else:
            parts.append("Ready to graduate!")
        
        return " | ".join(parts)
    
    def print_summary(self):
        """Print training summary."""
        print("\n" + "="*60)
        print("CURRICULUM TRAINING SUMMARY")
        print("="*60)
        
        for phase_data in self.phase_history:
            phase = Phase(phase_data['phase'])
            duration = phase_data['duration_seconds']
            hours = duration / 3600
            
            print(f"\nPhase {int(phase)}: {PHASE_CONFIGS[phase].description}")
            print(f"  Episodes: {phase_data['episodes']:,}")
            print(f"  Games: {phase_data['total_games']} (W:{phase_data['wins']} L:{phase_data['losses']} D:{phase_data['draws']})")
            print(f"  Best WR: {phase_data['best_win_rate']:.1%}")
            if phase_data['final_minimax_depth'] > 1:
                print(f"  Final Minimax Depth: {phase_data['final_minimax_depth']}")
            print(f"  Duration: {hours:.1f}h")
        
        if self.current_phase != Phase.COMPLETED:
            print(f"\nCurrent: Phase {int(self.current_phase)} - {self.get_config().description}")
            print(f"  Progress: {self.get_status_string()}")
        else:
            print("\n✅ TRAINING COMPLETED!")
        
        print("="*60 + "\n")


def calculate_win_reward(steps: int, max_steps: int = 200) -> float:
    """
    Calculate win reward based on game length.
    Fast wins (< 50 moves) get bonus, slow wins get less.
    Returns reward between 1.0 and 2.0
    """
    if steps < 50:
        # Fast win: full bonus
        return 2.0
    elif steps < 100:
        # Medium win: partial bonus
        return 1.5 + 0.5 * (100 - steps) / 50
    elif steps < 150:
        # Slow win: small bonus
        return 1.0 + 0.5 * (150 - steps) / 50
    else:
        # Very slow win: base reward
        return 1.0


def calculate_loss_penalty(steps: int, base_penalty: float = -1.5) -> float:
    """
    Calculate loss penalty based on game length.
    Fast losses are worse (didn't even try).
    Returns penalty between -2.0 and -1.0
    """
    if steps < 30:
        # Very fast loss: harsh penalty
        return base_penalty * 1.33  # e.g., -2.0
    elif steps < 60:
        # Fast loss: normal penalty
        return base_penalty
    else:
        # Slow loss (fought hard): reduced penalty
        return base_penalty * 0.67  # e.g., -1.0
