# fastnmm

An extremely fast Nine Men's Morris engine with an OpenSpiel-compatible
Python interface, built for AI training.

- **C++ bitboard core** exposed via pybind11 (~1.45× faster than OpenSpiel on
  Python-driven random playouts, higher still for the pure-C++ batch API).
- **OpenSpiel-compatible surface**: `load_game`, `new_initial_state`,
  `legal_actions`, `apply_action`, `is_terminal`, `returns`,
  `observation_tensor([5,7,7])`, `serialize`, etc. 1000/1000 random-game
  parity with `pyspiel.load_game("nine_mens_morris")` (modulo two
  documented OpenSpiel bugs — see `tests/test_openspiel_parity.py`).
- **Training extensions**:
  - Configurable starting-stone counts per player, e.g.
    `load_game(starting_stones=(5, 6))`.
  - Built-in `RandomBot` and `MinimaxBot` (alpha-beta negamax in C++).
  - `play_match` / `play_matches` runners. Any object with a
    `step(state) -> int` method works as a bot, so you can mix your own
    agents with the built-ins.
- **Tested**: 150 pytest tests across four test files.

## Install

```bash
cd fastnmm
pip install -e .

# optional extras for the parity test suite and benchmarks
pip install pytest numpy open_spiel
```

Requires a C++17 compiler (`g++` / `clang++`) and Python ≥ 3.8.

## Quick start

```python
import fastnmm

game  = fastnmm.load_game("nine_mens_morris")
state = game.new_initial_state()

while not state.is_terminal():
    action = state.legal_actions()[0]       # or your own policy
    state.apply_action(action)

print(state.returns())
```

## AI-training usage

### 1. Custom starting-stone counts

```python
# Either on the Game…
game  = fastnmm.load_game("nine_mens_morris", starting_stones=(5, 6))
state = game.new_initial_state()

# …or per state:
state = game.new_initial_state(starting_stones=[3, 7])
```

Values must be integers in `[1, 9]`. Asymmetric values like `(5, 6)`
work correctly: when one player finishes placing, that player enters
the moving phase while the other keeps placing.

### 2. Built-in bots — use either one, both, or mix with your own

```python
from fastnmm import RandomBot, MinimaxBot, play_match, play_matches

# Minimax as player 0, Random as player 1
returns = play_match([MinimaxBot(0, depth=4), RandomBot(1, seed=42)])

# Random as player 0, Minimax as player 1
returns = play_match([RandomBot(0, seed=0), MinimaxBot(1, depth=4)])

# Both sides are minimax (over the API)
returns = play_match([MinimaxBot(0, depth=3), MinimaxBot(1, depth=3)])

# Combine with custom stones
returns = play_match(
    [MinimaxBot(0, depth=4), RandomBot(1, seed=0)],
    starting_stones=(5, 6),
)

# Bulk matches with color swapping for fair evaluation
stats = play_matches(
    [MinimaxBot(0, depth=3), RandomBot(1)],
    num_games=100,
    starting_stones=(5, 6),
)
# stats == {"wins": [w0, w1], "draws": d, "returns": [[r0, r1], ...]}
```

### 3. Standalone bot use in your own training loop

```python
minimax = MinimaxBot(player_id=0, depth=4)
game    = fastnmm.load_game(starting_stones=(5, 6))
state   = game.new_initial_state()

while not state.is_terminal():
    if state.current_player() == 0:
        action = minimax.step(state)          # built-in picks
    else:
        action = your_agent.act(state)        # your model picks
    state.apply_action(action)

print(f"Return for your agent: {state.returns()[1]}")
print(f"Minimax search stats:  {minimax.last_search}")
```

Any duck-typed object with `step(state) -> int` works — no subclassing
required. `MinimaxBot.last_search` exposes `.action`, `.score`, and
`.nodes_visited` for telemetry.

## API reference

### `fastnmm.load_game(name="nine_mens_morris", starting_stones=None) -> Game`

OpenSpiel-compatible loader. Accepts aliases (`"morris"`, `"mühle"`,
`"mill"`, …). `starting_stones` is optional; defaults to `(9, 9)`.

### `Game`

`num_distinct_actions() → 600`, `num_players() → 2`,
`min_utility() → -1.0`, `max_utility() → 1.0`,
`observation_tensor_shape() → [5, 7, 7]`, `max_game_length()`,
`action_to_string(player, action)`, `deserialize_state(data)`,
`new_initial_state(starting_stones=None) -> State`.

### `State`

- `legal_actions() -> list[int]`
- `apply_action(action)`
- `is_terminal() -> bool`
- `current_player() -> int` (`-4` when terminal, matching OpenSpiel)
- `returns() -> [float, float]`, `rewards() -> [float, float]`
- `history() -> list[int]`, `move_number() -> int`
- `action_to_string(player, action) -> str`
- `observation_tensor(player=0) -> list[float]` (size 245)
- `observation_tensor_numpy(player=0) -> ndarray shape (5, 7, 7)`
- `observation_string(player=0) -> str`
- `serialize() -> str`, `clone() -> State`
- `current_phase() -> Phase`, `turn() -> int`, `winner() -> int`
- `men_to_deploy(player) -> int`, `men_on_board(player) -> int`
- `board_bitboard(player) -> int` (24-bit bitboard)
- `set_max_turns(n)`, `max_turns()`

### Action encoding (matches OpenSpiel exactly)

- `0..23` — place a stone at / capture a stone from position *p*
- `24..599` — move: `action = 24 + from*24 + to`
- Helpers: `fastnmm.encode_move(f, t)`, `fastnmm.move_from(a)`,
  `fastnmm.move_to(a)`, `fastnmm.is_move_action(a)`

### Bots — `fastnmm.bots` (also re-exported at top level)

- `RandomBot(player_id, seed=None)` — uniform random over
  `state.legal_actions()`. Reproducible when seeded; `restart()`
  resets the RNG.
- `MinimaxBot(player_id, depth=4)` — alpha-beta negamax in C++ with a
  material + mobility + mill heuristic. `.last_search` gives the most
  recent `SearchResult(action, score, nodes_visited)`.
- `make_uniform_random_bot(player_id, seed)` / `make_minimax_bot(player_id, depth)`
  — OpenSpiel-style factory aliases.
- `play_match(bots, starting_stones=None, max_turns=None, verbose=False) -> [r0, r1]`
- `play_matches(bots, num_games, starting_stones=None, max_turns=None, swap_colors=True) -> dict`

### Low-level search — `fastnmm` top level

- `minimax_search(state, depth=4) -> SearchResult` (releases the GIL)
- `minimax_action(state, depth=4) -> int`
- `evaluate(state) -> int` (static heuristic, no search)
- `random_playouts(num_games, seed=0, return_lengths=False) -> (sum_p0, lengths)`
  — pure-C++ batch rollouts for fast MC estimates.

## Tests

```bash
cd fastnmm
python -m pytest tests/
```

- `tests/test_basic.py` — API surface, state accessors, action encoding,
  clone/serialize, observation tensors.
- `tests/test_game_flow.py` — mill formation, capture rules, flying,
  stalemate, draws, phase transitions.
- `tests/test_openspiel_parity.py` — drives many random games through
  both engines and asserts state equivalence. Skipped if `pyspiel` is
  not installed.
- `tests/test_training.py` — custom starting stones, bot behaviour,
  `play_match` / `play_matches`, bot reproducibility, minimax beats
  random.

## Benchmark

```bash
python benchmarks/bench.py --games 2000
```

## Known differences from OpenSpiel

OpenSpiel's `legal_actions` omits two moves that its own transition
function accepts: `move 1 -> 0` (action 48) and `move 9 -> 0` (action
240). These are missing back-edges in OpenSpiel's neighbour list.
`fastnmm` lists these moves correctly, and as a knock-on effect, a
small fraction of random games terminate in OpenSpiel (false
stalemate) while continuing correctly in `fastnmm`. See
`tests/test_openspiel_parity.py` for the full discussion.

## License

Apache 2.0.
