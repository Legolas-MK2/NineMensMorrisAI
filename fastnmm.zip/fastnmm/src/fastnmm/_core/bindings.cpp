// pybind11 bindings for the Fast Nine Men's Morris engine.

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>

#include "nine_mens_morris.hpp"

#include <sstream>
#include <stdexcept>

namespace py = pybind11;
using namespace fastnmm;

PYBIND11_MODULE(_core, m) {
    m.doc() = "Fast Nine Men's Morris engine (bitboard, C++).";

    // --- constants ------------------------------------------------------
    m.attr("NUM_POSITIONS")        = kNumPositions;
    m.attr("NUM_PLAYERS")          = kNumPlayers;
    m.attr("PIECES_PER_PLAYER")    = kPiecesPerPlayer;
    m.attr("NUM_DISTINCT_ACTIONS") = kNumDistinctActions;
    m.attr("MOVE_ACTION_OFFSET")   = kMoveActionOffset;
    m.attr("OBSERVATION_PLANES")   = kObservationPlanes;
    m.attr("OBSERVATION_ROWS")     = kObservationRows;
    m.attr("OBSERVATION_COLS")     = kObservationCols;
    m.attr("OBSERVATION_SIZE")     = kObservationSize;
    m.attr("MAX_GAME_LENGTH")      = kMaxGameLength;
    m.attr("DEFAULT_MAX_TURNS")    = kMaxTurnsDefault;

    // --- Phase enum -----------------------------------------------------
    py::enum_<Phase>(m, "Phase")
        .value("PLACING",  Phase::kPlacing)
        .value("MOVING",   Phase::kMoving)
        .value("CAPTURE",  Phase::kCapture)
        .value("TERMINAL", Phase::kTerminal);

    // --- action encoding helpers ---------------------------------------
    m.def("is_move_action", &IsMoveAction);
    m.def("move_from",      &MoveFrom);
    m.def("move_to",        &MoveTo);
    m.def("encode_move",    &EncodeMove);

    // --- State ----------------------------------------------------------
    py::class_<State>(m, "State")
        .def(py::init<>())
        .def(py::init<int, int>(),
             py::arg("unplaced_white"), py::arg("unplaced_black"),
             "Custom-start state: each player begins with the given number "
             "of stones to place (must be in [1, 9]).")
        .def("legal_actions",
             [](const State& s) { return s.LegalActions(); },
             "Return the list of legal actions in the current state.")
        .def("apply_action",
             [](State& s, int a) { s.ApplyAction(a); },
             py::arg("action"))
        .def("is_terminal", &State::IsTerminal)
        .def("is_chance_node", &State::IsChanceNode)
        .def("current_player", &State::CurrentPlayer)
        .def("returns",
             [](const State& s) {
                 auto r = s.Returns();
                 return std::vector<float>{r[0], r[1]};
             })
        .def("rewards",
             [](const State& s) {
                 auto r = s.Rewards();
                 return std::vector<float>{r[0], r[1]};
             })
        .def("history", &State::History)
        .def("move_number", &State::MoveNumber)
        .def("action_to_string", &State::ActionToString,
             py::arg("player"), py::arg("action"))
        .def("__str__", &State::ToString)
        .def("to_string", &State::ToString)
        .def("observation_string", &State::ObservationString,
             py::arg("player") = 0)
        .def("information_state_string",
             [](const State& /*s*/, int /*player*/) { return std::string(""); },
             py::arg("player") = 0)
        .def("observation_tensor",
             [](const State& s, int player) {
                 auto arr = py::array_t<float>(kObservationSize);
                 s.ObservationTensor(player, arr.mutable_data());
                 // Return flat list-of-floats (matches OpenSpiel's Python API).
                 std::vector<float> out(kObservationSize);
                 std::memcpy(out.data(), arr.data(),
                             sizeof(float) * kObservationSize);
                 return out;
             },
             py::arg("player") = 0)
        .def("observation_tensor_numpy",
             [](const State& s, int player) {
                 auto arr = py::array_t<float>({kObservationPlanes,
                                                kObservationRows,
                                                kObservationCols});
                 s.ObservationTensor(player, arr.mutable_data());
                 return arr;
             },
             py::arg("player") = 0,
             "Return observation as a (5,7,7) numpy array (zero-copy path).")
        .def("clone", &State::Clone)
        .def("serialize", &State::Serialize)
        .def("__copy__",      [](const State& s) { return s.Clone(); })
        .def("__deepcopy__",  [](const State& s, py::dict /*memo*/) {
            return s.Clone();
        })
        .def("__repr__",
             [](const State& s) {
                 std::ostringstream os;
                 os << "<fastnmm.State turn=" << s.Turn()
                    << " phase=" << static_cast<int>(s.CurrentPhase())
                    << " current_player=" << s.CurrentPlayer()
                    << ">";
                 return os.str();
             })

        // Extras exposed as properties for convenience / testing.
        .def("board_bitboard", &State::Board, py::arg("player"),
             "Return the 24-bit bitboard for the given player.")
        .def("men_to_deploy",  &State::MenToDeploy, py::arg("player"))
        .def("men_on_board",   &State::MenOnBoard,  py::arg("player"))
        .def("current_phase",  &State::CurrentPhase)
        .def("turn",           &State::Turn)
        .def("winner",         &State::Winner)
        .def("is_action_legal",&State::IsActionLegal, py::arg("action"))
        .def("set_max_turns",  &State::SetMaxTurns,   py::arg("max_turns"))
        .def("max_turns",      &State::MaxTurns);

    // --- Game -----------------------------------------------------------
    py::class_<Game>(m, "Game")
        .def(py::init<>())
        .def_static("num_distinct_actions",    &Game::NumDistinctActions)
        .def_static("num_players",             &Game::NumPlayers)
        .def_static("min_utility",             &Game::MinUtility)
        .def_static("max_utility",             &Game::MaxUtility)
        .def_static("utility_sum",             &Game::UtilitySum)
        .def_static("max_game_length",         &Game::MaxGameLength)
        .def_static("observation_tensor_shape",
                    []() {
                        auto s = Game::ObservationTensorShape();
                        return std::vector<int>{s[0], s[1], s[2]};
                    })
        .def_static("observation_tensor_size", &Game::ObservationTensorSize)
        .def_static("new_initial_state",
                    py::overload_cast<>(&Game::NewInitialState))
        .def_static("new_initial_state",
                    py::overload_cast<int, int>(&Game::NewInitialState),
                    py::arg("unplaced_white"), py::arg("unplaced_black"))
        .def_static("action_to_string",        &Game::ActionToString,
                    py::arg("player"), py::arg("action"))
        .def_static("deserialize_state",       &Game::Deserialize,
                    py::arg("data"));

    // --- free functions / helpers --------------------------------------
    m.def("new_initial_state",
          py::overload_cast<>(&Game::NewInitialState),
          "Create a fresh initial state (9,9 stones).");
    m.def("new_initial_state_with_stones",
          py::overload_cast<int, int>(&Game::NewInitialState),
          py::arg("unplaced_white"), py::arg("unplaced_black"),
          "Create a fresh initial state with custom starting stones per player.");
    m.def("action_to_string",
          [](int player, int action) { return Game::ActionToString(player, action); },
          py::arg("player"), py::arg("action"));
    m.def("deserialize_state", &Game::Deserialize, py::arg("data"));

    // --- Minimax / evaluation ------------------------------------------
    py::class_<SearchResult>(m, "SearchResult")
        .def_readonly("action",        &SearchResult::action)
        .def_readonly("score",         &SearchResult::score)
        .def_readonly("nodes_visited", &SearchResult::nodes_visited)
        .def("__repr__", [](const SearchResult& r) {
            std::ostringstream os;
            os << "<SearchResult action=" << r.action
               << " score=" << r.score
               << " nodes=" << r.nodes_visited << ">";
            return os.str();
        });

    m.def("minimax_search",
          [](const State& s, int depth) {
              SearchResult r;
              {
                  py::gil_scoped_release release;
                  r = MinimaxSearch(s, depth);
              }
              return r;
          },
          py::arg("state"), py::arg("depth") = 4,
          "Run alpha-beta negamax on `state` to the given ply `depth`. "
          "Returns a SearchResult with the best action, its score, and "
          "the number of nodes visited.");

    m.def("minimax_action",
          [](const State& s, int depth) {
              SearchResult r;
              {
                  py::gil_scoped_release release;
                  r = MinimaxSearch(s, depth);
              }
              return r.action;
          },
          py::arg("state"), py::arg("depth") = 4,
          "Shortcut for `minimax_search(state, depth).action`.");

    m.def("evaluate", &Evaluate, py::arg("state"),
          "Static heuristic value of `state` from its current player's "
          "perspective. Does not search.");

    // Pure-C++ random rollouts (releases the GIL so callers can parallelise).
    m.def(
        "random_playouts",
        [](int num_games, uint64_t seed, bool return_lengths) {
            std::vector<int> lengths;
            if (return_lengths) lengths.resize(num_games);
            double sum_p0;
            {
                py::gil_scoped_release release;
                sum_p0 = RandomPlayouts(num_games, seed,
                                        return_lengths ? lengths.data() : nullptr);
            }
            return py::make_tuple(sum_p0, lengths);
        },
        py::arg("num_games"),
        py::arg("seed") = 0,
        py::arg("return_lengths") = false,
        "Play `num_games` random games in pure C++ and return "
        "(sum_of_player0_returns, list_of_game_lengths_or_empty).");
}
