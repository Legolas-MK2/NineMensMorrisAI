// Fast Nine Men's Morris engine using bitboards.
// Interface designed to match OpenSpiel's nine_mens_morris game.
//
// Action encoding (matches OpenSpiel exactly):
//   0..23    : place at / capture from position p        (action = p)
//   24..599  : move from f to t                          (action = 24 + f*24 + t)
//
// Total distinct actions: 600.

#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace fastnmm {

// ----- Game constants -----
constexpr int kNumPositions      = 24;
constexpr int kNumPlayers        = 2;
constexpr int kPiecesPerPlayer   = 9;
constexpr int kNumDistinctActions = 600;
constexpr int kMoveActionOffset  = 24;          // moves start at action 24
constexpr int kMaxTurnsDefault   = 200;         // OpenSpiel draw threshold
constexpr int kMaxGameLength     = 1000;        // hard safety bound
constexpr int kObservationPlanes = 5;
constexpr int kObservationRows   = 7;
constexpr int kObservationCols   = 7;
constexpr int kObservationSize   = kObservationPlanes * kObservationRows * kObservationCols;

// Players (matches OpenSpiel: 0 = White, 1 = Black).
constexpr int kWhite = 0;
constexpr int kBlack = 1;

// Phase of the game.
enum class Phase : uint8_t {
    kPlacing  = 0,
    kMoving   = 1,
    kCapture  = 2,  // awaiting removal choice after a mill formed
    kTerminal = 3,
};

// 24-bit bitboard (bit i set iff position i occupied).
using BitBoard = uint32_t;
constexpr BitBoard kFullBoard = (1u << kNumPositions) - 1u;

// ----- Precomputed tables (defined in .cpp) -----
extern const BitBoard* const kAdjacency;   // length kNumPositions
extern const BitBoard* const kMillMasks;   // length 16
extern const BitBoard* const kPosMill1;    // length kNumPositions
extern const BitBoard* const kPosMill2;    // length kNumPositions
extern const int kBoardRow[kNumPositions]; // row in 7x7 display grid
extern const int kBoardCol[kNumPositions]; // col in 7x7 display grid
extern const uint8_t kObsPlane3Mask[kObservationRows][kObservationCols];
extern const uint8_t kObsPlane4Mask[kObservationRows][kObservationCols];

// ----- State -----
class State {
public:
    // Standard game: both players start with 9 stones.
    State();

    // Training variant: each player starts with `unplaced_white` /
    // `unplaced_black` stones to place. Both values must be in [1, 9].
    // Any ValueError in the input is raised as std::invalid_argument.
    State(int unplaced_white, int unplaced_black);

    // Core OpenSpiel-style API.
    std::vector<int>  LegalActions() const;
    void              ApplyAction(int action);
    bool              IsTerminal() const { return phase_ == Phase::kTerminal; }
    bool              IsChanceNode() const { return false; }
    int               CurrentPlayer() const;          // returns kTerminalPlayer if terminal
    std::array<float, 2> Returns() const;
    std::array<float, 2> Rewards() const { return last_rewards_; }
    std::vector<int>  History() const { return history_; }
    int               MoveNumber() const { return static_cast<int>(history_.size()); }
    std::string       ToString() const;
    std::string       ActionToString(int player, int action) const;
    std::string       ObservationString(int player) const { (void)player; return ToString(); }
    void              ObservationTensor(int player, float* out) const;
    std::string       Serialize() const;
    State             Clone() const { return *this; }

    // Extra helpers (useful for Python users & tests).
    BitBoard  Board(int player) const { return board_[player]; }
    int       MenToDeploy(int player) const { return unplaced_[player]; }
    int       MenOnBoard(int player) const { return on_board_[player]; }
    Phase     CurrentPhase() const;   // derives placing/moving per-player
    int       Turn() const { return turn_; }
    int       Winner() const { return winner_; }   // -1 ongoing, 0/1 player, 2 draw

    // Fast helpers that don't allocate.
    int LegalActionsInto(int* out) const;   // writes into out, returns count
    bool IsActionLegal(int action) const;

    // Static constant for "terminal" player id (matches OpenSpiel).
    static constexpr int kTerminalPlayer = -4;

    // Default draw threshold (in "turns", not actions). Configurable for advanced use.
    void SetMaxTurns(int t) { max_turns_ = t; }
    int  MaxTurns() const { return max_turns_; }

private:
    // Bitboards per player.
    BitBoard board_[2];
    int8_t   unplaced_[2];    // pieces left to place (0..9)
    int8_t   on_board_[2];    // pieces currently on the board
    int8_t   current_player_;
    Phase    phase_;
    int16_t  turn_;           // "turn" counter (like OpenSpiel: does NOT tick on captures)
    int8_t   winner_;         // -1 ongoing, 0/1 player, 2 draw
    int16_t  max_turns_;
    std::array<float, 2> last_rewards_;
    std::vector<int> history_;

    // Internal helpers.
    void ApplyPlace(int pos);
    void ApplyMove(int from, int to);
    void ApplyCapture(int pos);

    bool FormedMillAt(int pos, int player) const;
    bool PieceInMill(int pos, int player) const;
    bool HasAnyLegalMove(int player) const;

    void EndGame(int winner_player);   // 0/1 winning, or 2 for draw
    void CheckDrawAndStalemate();      // called after each "turn" transition
};

// ----- Game (static/factory). -----
struct Game {
    static int NumDistinctActions() { return kNumDistinctActions; }
    static int NumPlayers()         { return kNumPlayers; }
    static float MinUtility()       { return -1.0f; }
    static float MaxUtility()       { return 1.0f; }
    static float UtilitySum()       { return 0.0f; }
    static int MaxGameLength()      { return kMaxGameLength; }
    static std::array<int, 3> ObservationTensorShape() {
        return {kObservationPlanes, kObservationRows, kObservationCols};
    }
    static int ObservationTensorSize()   { return kObservationSize; }
    static State NewInitialState()       { return State(); }
    static State NewInitialState(int uw, int ub) { return State(uw, ub); }
    static std::string ActionToString(int player, int action);
    static State Deserialize(const std::string& data);
};

// ----- Bots -----
// Pick a random legal action (xorshift64 RNG).
int RandomAction(const State& s, uint64_t& rng);

// Depth-limited negamax with alpha-beta. Returns (best_action, score).
// Score is from the perspective of the state's current player.
// Terminal / game-over scores use kWinScore ± depth tie-breaking.
// Higher `depth` => stronger but slower.
struct SearchResult {
    int action;
    int score;
    long nodes_visited;
};
SearchResult MinimaxSearch(const State& s, int depth);

// Static evaluation heuristic (from perspective of `s.CurrentPlayer()`).
int Evaluate(const State& s);

// Inline decoding helpers.
inline bool IsMoveAction(int action)  { return action >= kMoveActionOffset; }
inline int  MoveFrom(int action)      { return (action - kMoveActionOffset) / kNumPositions; }
inline int  MoveTo(int action)        { return (action - kMoveActionOffset) % kNumPositions; }
inline int  EncodeMove(int from, int to) {
    return kMoveActionOffset + from * kNumPositions + to;
}

// Run N random rollouts from the initial state, returning the sum of player-0
// returns (useful for pure-C++ benchmarking and Monte Carlo estimates).
// When `out_lengths` is non-null, writes the length of each game (in actions).
double RandomPlayouts(int num_games, uint64_t seed,
                      int* out_lengths = nullptr);

}  // namespace fastnmm
