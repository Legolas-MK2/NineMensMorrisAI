// Fast Nine Men's Morris engine -- implementation.

#include "nine_mens_morris.hpp"

#include <algorithm>
#include <cstring>
#include <sstream>
#include <stdexcept>

namespace fastnmm {

// =========================================================================
// Precomputed tables.
// =========================================================================

namespace {

// Adjacency list: adjacency[i] = list of positions adjacent to i.
constexpr int kAdj[kNumPositions][4] = {
    {  1,  9, -1, -1},   //  0
    {  0,  2,  4, -1},   //  1
    {  1, 14, -1, -1},   //  2
    {  4, 10, -1, -1},   //  3
    {  1,  3,  5,  7},   //  4
    {  4, 13, -1, -1},   //  5
    {  7, 11, -1, -1},   //  6
    {  4,  6,  8, -1},   //  7
    {  7, 12, -1, -1},   //  8
    {  0, 10, 21, -1},   //  9
    {  3,  9, 11, 18},   // 10
    {  6, 10, 15, -1},   // 11
    {  8, 13, 17, -1},   // 12
    {  5, 12, 14, 20},   // 13
    {  2, 13, 23, -1},   // 14
    { 11, 16, -1, -1},   // 15
    { 15, 17, 19, -1},   // 16
    { 12, 16, -1, -1},   // 17
    { 10, 19, -1, -1},   // 18
    { 16, 18, 20, 22},   // 19
    { 13, 19, -1, -1},   // 20
    {  9, 22, -1, -1},   // 21
    { 19, 21, 23, -1},   // 22
    { 14, 22, -1, -1},   // 23
};

// 16 mills (3-in-a-row lines).
constexpr int kMills[16][3] = {
    // Horizontal mills:
    { 0,  1,  2}, { 3,  4,  5}, { 6,  7,  8},
    { 9, 10, 11}, {12, 13, 14},
    {15, 16, 17}, {18, 19, 20}, {21, 22, 23},
    // Vertical mills:
    { 0,  9, 21}, { 3, 10, 18}, { 6, 11, 15},
    { 1,  4,  7}, {16, 19, 22},
    { 8, 12, 17}, { 5, 13, 20}, { 2, 14, 23},
};

// 7x7 display coordinates for each position (row, col).
constexpr int kCoords[kNumPositions][2] = {
    {0,0}, {0,3}, {0,6},
    {1,1}, {1,3}, {1,5},
    {2,2}, {2,3}, {2,4},
    {3,0}, {3,1}, {3,2},
    {3,4}, {3,5}, {3,6},
    {4,2}, {4,3}, {4,4},
    {5,1}, {5,3}, {5,5},
    {6,0}, {6,3}, {6,6},
};

// Helper to build bitboard from a list of positions.
constexpr BitBoard MakeMask(const int* pts, int n) {
    BitBoard m = 0;
    for (int i = 0; i < n; ++i) m |= (1u << pts[i]);
    return m;
}

}  // anonymous namespace

// Initialize tables at program start.
namespace detail {

std::array<BitBoard, kNumPositions> InitAdjacency() {
    std::array<BitBoard, kNumPositions> arr{};
    for (int i = 0; i < kNumPositions; ++i) {
        BitBoard m = 0;
        for (int j = 0; j < 4; ++j) {
            if (kAdj[i][j] >= 0) m |= (1u << kAdj[i][j]);
        }
        arr[i] = m;
    }
    return arr;
}

std::array<BitBoard, 16> InitMillMasks() {
    std::array<BitBoard, 16> arr{};
    for (int i = 0; i < 16; ++i) {
        arr[i] = (1u << kMills[i][0]) | (1u << kMills[i][1]) | (1u << kMills[i][2]);
    }
    return arr;
}

// For each position, the two mill masks it belongs to. Every position
// participates in exactly 2 mills (one horizontal, one vertical).
void InitPositionMills(std::array<BitBoard, kNumPositions>& p1,
                       std::array<BitBoard, kNumPositions>& p2) {
    p1.fill(0);
    p2.fill(0);
    for (int pos = 0; pos < kNumPositions; ++pos) {
        BitBoard first = 0;
        for (int m = 0; m < 16; ++m) {
            BitBoard mask = (1u << kMills[m][0]) | (1u << kMills[m][1]) | (1u << kMills[m][2]);
            if (mask & (1u << pos)) {
                if (first == 0) { p1[pos] = mask; first = mask; }
                else            { p2[pos] = mask; break; }
            }
        }
    }
}

}  // namespace detail

// Static init via function-local statics (thread-safe in C++11).
namespace {
const auto& Adjacency() {
    static const auto v = detail::InitAdjacency();
    return v;
}
const auto& MillMasksArr() {
    static const auto v = detail::InitMillMasks();
    return v;
}
struct PosMills { std::array<BitBoard, kNumPositions> p1, p2; };
const PosMills& PositionMills() {
    static const PosMills v = [] {
        PosMills pm;
        detail::InitPositionMills(pm.p1, pm.p2);
        return pm;
    }();
    return v;
}
}  // namespace

// Public-accessible arrays (exposed via extern declarations).
const BitBoard* const kAdjacency = Adjacency().data();
const BitBoard* const kMillMasks = MillMasksArr().data();
const BitBoard* const kPosMill1  = PositionMills().p1.data();
const BitBoard* const kPosMill2  = PositionMills().p2.data();
const int       kBoardRow[kNumPositions] = {
    0,0,0, 1,1,1, 2,2,2, 3,3,3, 3,3,3, 4,4,4, 5,5,5, 6,6,6
};
const int       kBoardCol[kNumPositions] = {
    0,3,6, 1,3,5, 2,3,4, 0,1,2, 4,5,6, 2,3,4, 1,3,5, 0,3,6
};

// Structural observation-tensor planes (3 and 4). These are constant masks
// that encode the board's geometric edges, matching OpenSpiel's output.
// Derived empirically from the OpenSpiel reference engine.
const uint8_t kObsPlane3Mask[kObservationRows][kObservationCols] = {
    {0,1,1,0,1,1,0},
    {0,0,1,0,1,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,1,0,1,0,0},
    {0,1,1,0,1,1,0},
};
const uint8_t kObsPlane4Mask[kObservationRows][kObservationCols] = {
    {0,0,0,0,0,0,0},
    {1,0,0,0,0,0,1},
    {1,1,0,0,0,1,1},
    {0,0,0,0,0,0,0},
    {1,1,0,0,0,1,1},
    {1,0,0,0,0,0,1},
    {0,0,0,0,0,0,0},
};

// =========================================================================
// State
// =========================================================================

State::State() : State(kPiecesPerPlayer, kPiecesPerPlayer) {}

State::State(int unplaced_white, int unplaced_black)
    : board_{0, 0},
      unplaced_{static_cast<int8_t>(unplaced_white),
                static_cast<int8_t>(unplaced_black)},
      on_board_{0, 0},
      current_player_(kWhite),
      phase_(Phase::kPlacing),
      turn_(0),
      winner_(-1),
      max_turns_(kMaxTurnsDefault),
      last_rewards_{0.0f, 0.0f},
      history_{} {
    if (unplaced_white < 1 || unplaced_white > kPiecesPerPlayer ||
        unplaced_black < 1 || unplaced_black > kPiecesPerPlayer) {
        throw std::invalid_argument(
            "starting stones must be in [1, 9] for each player");
    }
    history_.reserve(256);
}

int State::CurrentPlayer() const {
    return (phase_ == Phase::kTerminal) ? kTerminalPlayer : current_player_;
}

std::array<float, 2> State::Returns() const {
    if (phase_ != Phase::kTerminal) return {0.0f, 0.0f};
    if (winner_ == 2)               return {0.0f, 0.0f};   // draw
    if (winner_ == 0)               return {1.0f, -1.0f};
    /* winner_ == 1 */              return {-1.0f, 1.0f};
}

Phase State::CurrentPhase() const {
    if (phase_ == Phase::kTerminal) return Phase::kTerminal;
    if (phase_ == Phase::kCapture)  return Phase::kCapture;
    return (unplaced_[current_player_] > 0) ? Phase::kPlacing : Phase::kMoving;
}

// ----- Mill detection.
bool State::FormedMillAt(int pos, int player) const {
    const BitBoard b = board_[player];
    const BitBoard m1 = kPosMill1[pos];
    const BitBoard m2 = kPosMill2[pos];
    return ((b & m1) == m1) || (m2 != 0 && (b & m2) == m2);
}

bool State::PieceInMill(int pos, int player) const {
    return FormedMillAt(pos, player);
}

// ----- Legal-move computation.
bool State::HasAnyLegalMove(int player) const {
    const BitBoard own = board_[player];
    const BitBoard occ = board_[0] | board_[1];
    const BitBoard empty = (~occ) & kFullBoard;

    // Flying? (exactly 3 pieces, 0 unplaced.)
    const bool flying = (on_board_[player] == 3) && (unplaced_[player] == 0);
    if (flying) {
        // Any own piece and any empty square ==> always at least one move
        // (since own >= 3 and empty >= 1).
        return (own != 0) && (empty != 0);
    }
    // Standard movement: any own piece with an empty adjacent square.
    BitBoard pieces = own;
    while (pieces) {
        const int pos = __builtin_ctz(pieces);
        pieces &= pieces - 1;
        if (kAdjacency[pos] & empty) return true;
    }
    return false;
}

int State::LegalActionsInto(int* out) const {
    if (phase_ == Phase::kTerminal) return 0;

    int n = 0;

    if (phase_ == Phase::kCapture) {
        // Remove opponent piece. Prefer non-mill pieces; if all opponent pieces
        // are in mills, any of them can be captured.
        const int opp = 1 - current_player_;
        const BitBoard opp_b = board_[opp];
        BitBoard non_mill = opp_b;
        const auto& millsA = MillMasksArr();
        for (int i = 0; i < 16; ++i) {
            if ((opp_b & millsA[i]) == millsA[i]) {
                non_mill &= ~millsA[i];
            }
        }
        BitBoard choices = (non_mill != 0) ? non_mill : opp_b;
        while (choices) {
            const int p = __builtin_ctz(choices);
            choices &= choices - 1;
            out[n++] = p;
        }
        return n;
    }

    // Placing vs. moving is per-player: if this player still has stones
    // to deploy, they place; otherwise they move (possibly flying).
    if (unplaced_[current_player_] > 0) {
        const BitBoard empty = (~(board_[0] | board_[1])) & kFullBoard;
        BitBoard m = empty;
        while (m) {
            const int p = __builtin_ctz(m);
            m &= m - 1;
            out[n++] = p;
        }
        return n;
    }

    // Moving phase for this player.
    const BitBoard own = board_[current_player_];
    const BitBoard occ = board_[0] | board_[1];
    const BitBoard empty = (~occ) & kFullBoard;
    const bool flying = (on_board_[current_player_] == 3) && (unplaced_[current_player_] == 0);

    BitBoard pieces = own;
    while (pieces) {
        const int from = __builtin_ctz(pieces);
        pieces &= pieces - 1;
        BitBoard targets = flying ? empty : (kAdjacency[from] & empty);
        while (targets) {
            const int to = __builtin_ctz(targets);
            targets &= targets - 1;
            out[n++] = EncodeMove(from, to);
        }
    }
    return n;
}

std::vector<int> State::LegalActions() const {
    if (phase_ == Phase::kTerminal) return {};
    // Upper bound: moving phase flying worst case = 9 pieces * 21 empties = 189.
    int buf[256];
    const int n = LegalActionsInto(buf);
    return std::vector<int>(buf, buf + n);
}

bool State::IsActionLegal(int action) const {
    int buf[256];
    const int n = LegalActionsInto(buf);
    for (int i = 0; i < n; ++i) if (buf[i] == action) return true;
    return false;
}

// ----- Apply a single action.
void State::ApplyAction(int action) {
    if (phase_ == Phase::kTerminal) {
        throw std::runtime_error("ApplyAction called on terminal state.");
    }
    last_rewards_ = {0.0f, 0.0f};

    if (phase_ == Phase::kCapture) {
        if (action < 0 || action >= kNumPositions) {
            throw std::runtime_error("Invalid capture action.");
        }
        ApplyCapture(action);
    } else if (unplaced_[current_player_] > 0) {
        // This player still has stones to deploy -> placing.
        if (action < 0 || action >= kNumPositions) {
            throw std::runtime_error("Invalid place action.");
        }
        ApplyPlace(action);
    } else {
        // This player is in moving phase (even if the other still places).
        if (!IsMoveAction(action) || action >= kNumDistinctActions) {
            throw std::runtime_error("Invalid move action in moving phase.");
        }
        ApplyMove(MoveFrom(action), MoveTo(action));
    }

    history_.push_back(action);
}

void State::ApplyPlace(int pos) {
    const int p = current_player_;
    if (((board_[0] | board_[1]) >> pos) & 1) {
        throw std::runtime_error("Cannot place on occupied point.");
    }
    if (unplaced_[p] <= 0) {
        throw std::runtime_error("No pieces left to place.");
    }
    board_[p]    |= (1u << pos);
    unplaced_[p] -= 1;
    on_board_[p] += 1;

    const bool mill = FormedMillAt(pos, p);
    if (mill) {
        // Enter capture phase (current player must pick opponent piece).
        phase_ = Phase::kCapture;
        return;
    }

    // Advance: next player.
    turn_ += 1;
    current_player_ = 1 - p;

    CheckDrawAndStalemate();
}

void State::ApplyMove(int from, int to) {
    const int p = current_player_;
    if (!((board_[p] >> from) & 1)) {
        throw std::runtime_error("Source position does not contain own piece.");
    }
    if (((board_[0] | board_[1]) >> to) & 1) {
        throw std::runtime_error("Destination is occupied.");
    }
    const bool flying = (on_board_[p] == 3) && (unplaced_[p] == 0);
    if (!flying && !(kAdjacency[from] & (1u << to))) {
        throw std::runtime_error("Non-adjacent move while not in flying phase.");
    }
    board_[p] ^= (1u << from);
    board_[p] |= (1u << to);

    if (FormedMillAt(to, p)) {
        phase_ = Phase::kCapture;
        return;
    }

    turn_ += 1;
    current_player_ = 1 - p;
    CheckDrawAndStalemate();
}

void State::ApplyCapture(int pos) {
    const int p = current_player_;
    const int opp = 1 - p;
    if (!((board_[opp] >> pos) & 1)) {
        throw std::runtime_error("Capture target not an opponent piece.");
    }
    // Enforce "cannot take from mill unless all in mills" rule.
    const BitBoard opp_b = board_[opp];
    BitBoard non_mill = opp_b;
    for (int i = 0; i < 16; ++i) {
        if ((opp_b & kMillMasks[i]) == kMillMasks[i]) {
            non_mill &= ~kMillMasks[i];
        }
    }
    if (non_mill != 0 && !((non_mill >> pos) & 1)) {
        throw std::runtime_error(
            "Cannot capture piece in a mill while opponent has non-mill pieces.");
    }

    board_[opp]    ^= (1u << pos);
    on_board_[opp] -= 1;

    // After capture, control returns to the opponent (per standard rules).
    turn_ += 1;
    current_player_ = opp;
    phase_ = Phase::kPlacing;   // nominal; effective phase is derived in
                                // LegalActions from unplaced_[current_player_]

    // Check win by piece count: the captured side loses if they have
    // no more stones to deploy AND < 3 stones on the board.
    if (unplaced_[opp] == 0 && on_board_[opp] < 3) {
        EndGame(p);
        return;
    }
    CheckDrawAndStalemate();
}

void State::EndGame(int winner_player) {
    // winner_player: 0 or 1 for a winning player, 2 for draw.
    phase_ = Phase::kTerminal;
    winner_ = static_cast<int8_t>(winner_player);
    if (winner_player == 2) {
        last_rewards_ = {0.0f, 0.0f};
    } else if (winner_player == 0) {
        last_rewards_ = {1.0f, -1.0f};
    } else {
        last_rewards_ = {-1.0f, 1.0f};
    }
}

void State::CheckDrawAndStalemate() {
    // Max-turn draw applies in all non-terminal phases.
    if (turn_ >= max_turns_) { EndGame(2); return; }

    // Stalemate applies only when the current player is in their *moving*
    // sub-phase (they have no stones left to place). A player who still has
    // stones to place can always play (empty points are plentiful).
    if (phase_ == Phase::kCapture) return;
    if (unplaced_[current_player_] > 0) return;   // still placing
    if (!HasAnyLegalMove(current_player_)) {
        EndGame(1 - current_player_);
    }
}

// ----- String rendering.
// Render in OpenSpiel's ASCII format, using W/B/'.' for white/black/empty.
std::string State::ToString() const {
    // The OpenSpiel layout:
    //   .------.------.
    //   |      |      |
    //   | .----.----. |
    //   | |    |    | |
    //   | | .--.--. | |
    //   | | |     | | |
    //   .-.-.     .-.-.
    //   | | |     | | |
    //   | | .--.--. | |
    //   | |    |    | |
    //   | .----.----. |
    //   |      |      |
    //   .------.------.
    //
    // The positions 0..23 show up at specific character columns.
    const char glyph[3] = {'W', 'B', '.'};

    auto at = [&](int idx) -> char {
        if ((board_[0] >> idx) & 1) return glyph[0];
        if ((board_[1] >> idx) & 1) return glyph[1];
        return glyph[2];
    };

    std::ostringstream os;
    os << at( 0) << "------" << at( 1) << "------" << at( 2) << "\n";
    os << "|      |      |\n";
    os << "| "    << at( 3) << "----"   << at( 4) << "----"   << at( 5) << " |\n";
    os << "| |    |    | |\n";
    os << "| | "  << at( 6) << "--"     << at( 7) << "--"     << at( 8) << " | |\n";
    os << "| | |     | | |\n";
    os << at( 9) << "-"     << at(10)   << "-"     << at(11)
       << "     "
       << at(12) << "-"     << at(13)   << "-"     << at(14) << "\n";
    os << "| | |     | | |\n";
    os << "| | "  << at(15) << "--"     << at(16) << "--"     << at(17) << " | |\n";
    os << "| |    |    | |\n";
    os << "| "    << at(18) << "----"   << at(19) << "----"   << at(20) << " |\n";
    os << "|      |      |\n";
    os << at(21) << "------" << at(22) << "------" << at(23) << "\n";
    os << "\n";
    os << "Current player: "
       << (phase_ == Phase::kTerminal
           ? (winner_ == 2 ? "-" : (winner_ == 0 ? "W" : "B"))
           : (current_player_ == 0 ? "W" : "B"))
       << "\n";
    os << "Turn number: " << turn_ << "\n";
    os << "Men to deploy: " << static_cast<int>(unplaced_[0]) << " "
                           << static_cast<int>(unplaced_[1]) << "\n";
    os << "Num men: "
       << static_cast<int>(on_board_[0] + unplaced_[0]) << " "
       << static_cast<int>(on_board_[1] + unplaced_[1]) << "\n";
    if (phase_ == Phase::kCapture) {
        os << "Last move formed a mill. Capture time!\n";
    }
    return os.str();
}

std::string State::ActionToString(int player, int action) const {
    (void)player;
    return Game::ActionToString(player, action);
}

std::string Game::ActionToString(int /*player*/, int action) {
    if (action < 0 || action >= kNumDistinctActions) {
        return "InvalidAction";
    }
    if (IsMoveAction(action)) {
        std::ostringstream os;
        os << "Move " << MoveFrom(action) << " -> " << MoveTo(action);
        return os.str();
    }
    std::ostringstream os;
    os << "Point " << action;
    return os.str();
}

// ----- Observation tensor (5,7,7).
// Plane 0: White pieces
// Plane 1: Black pieces
// Plane 2: Empty valid points (mask of 24 valid points minus occupied)
// Plane 3: Structural edges (horizontal connectors)
// Plane 4: Structural edges (vertical connectors)
void State::ObservationTensor(int /*player*/, float* out) const {
    std::memset(out, 0, sizeof(float) * kObservationSize);
    const int plane_stride = kObservationRows * kObservationCols;

    // Plane 0 & 1: pieces.
    for (int pos = 0; pos < kNumPositions; ++pos) {
        const int r = kBoardRow[pos];
        const int c = kBoardCol[pos];
        const int offset = r * kObservationCols + c;
        if ((board_[0] >> pos) & 1) out[0 * plane_stride + offset] = 1.0f;
        else if ((board_[1] >> pos) & 1) out[1 * plane_stride + offset] = 1.0f;
        else out[2 * plane_stride + offset] = 1.0f;  // empty valid point
    }

    // Plane 3 & 4: structural masks (constant).
    for (int r = 0; r < kObservationRows; ++r) {
        for (int c = 0; c < kObservationCols; ++c) {
            if (kObsPlane3Mask[r][c])
                out[3 * plane_stride + r * kObservationCols + c] = 1.0f;
            if (kObsPlane4Mask[r][c])
                out[4 * plane_stride + r * kObservationCols + c] = 1.0f;
        }
    }
}

// ----- Serialization (simple: one action per line, like OpenSpiel).
std::string State::Serialize() const {
    std::ostringstream os;
    for (int a : history_) os << a << "\n";
    return os.str();
}

State Game::Deserialize(const std::string& data) {
    State s;
    std::istringstream is(data);
    std::string line;
    while (std::getline(is, line)) {
        if (line.empty()) continue;
        s.ApplyAction(std::stoi(line));
    }
    return s;
}

// Simple fast xorshift64 RNG.
namespace {
inline uint64_t XorShift64(uint64_t& x) {
    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
    return x;
}

// Bitboard popcount helper.
inline int PopCount(BitBoard b) { return __builtin_popcount(b); }

// How many mills does `player` currently have on board?
inline int MillCount(const State& s, int player) {
    const BitBoard b = s.Board(player);
    int n = 0;
    for (int i = 0; i < 16; ++i) {
        if ((b & kMillMasks[i]) == kMillMasks[i]) ++n;
    }
    return n;
}
}  // namespace

int RandomAction(const State& s, uint64_t& rng) {
    int buf[256];
    const int n = s.LegalActionsInto(buf);
    if (n <= 0) return -1;
    return buf[XorShift64(rng) % static_cast<uint64_t>(n)];
}

// -----------------------------------------------------------------------
// Evaluation heuristic.
//
// Score is from the perspective of the *current* player of `s`.
// Components (all differences are own - opponent):
//   material      (10 * diff)  -- on-board + unplaced pieces
//   mills         ( 3 * diff)  -- completed 3-in-a-row lines
//   mobility      ( 1 * diff)  -- number of legal moves (approx)
// Terminal wins return kWinScore; terminal losses return -kWinScore.
// Draws return 0.
// -----------------------------------------------------------------------
namespace {
constexpr int kWinScore = 100000;

// Count a player's (approximate) mobility: number of (from, to) or
// placement actions available to them *if it were their turn*. Cheap
// version: count own pieces * empty-adjacent for moving phase,
// or empties for placing phase.
int ApproxMobility(const State& s, int player) {
    const BitBoard own = s.Board(player);
    const BitBoard occ = s.Board(0) | s.Board(1);
    const BitBoard empty = (~occ) & kFullBoard;

    // If any pieces left to place, placement candidates = empty points.
    int mob = 0;
    if (s.MenToDeploy(player) > 0) {
        mob += PopCount(empty);
    }
    // Movement / flying mobility.
    const bool flying = (s.MenOnBoard(player) == 3) &&
                        (s.MenToDeploy(player) == 0);
    if (flying) {
        mob += PopCount(own) * PopCount(empty);
    } else {
        BitBoard pieces = own;
        while (pieces) {
            const int pos = __builtin_ctz(pieces);
            pieces &= pieces - 1;
            mob += PopCount(kAdjacency[pos] & empty);
        }
    }
    return mob;
}
}  // namespace

int Evaluate(const State& s) {
    if (s.IsTerminal()) {
        const int w = s.Winner();
        if (w == 2) return 0;  // draw
        // Evaluate from perspective of the player "to move" even when
        // terminal (no one is to move, but we still return a signed score).
        // After terminal the current_player is TerminalPlayer; fall back
        // to last mover being the OPPONENT of the one who would move next.
        // Simplest: the winner gets +kWinScore regardless of current_player.
        // Callers only use Evaluate at the root / internal nodes via
        // negamax, which passes them before a node becomes terminal.
        return kWinScore;  // unused from search; see MinimaxSearch.
    }
    const int cp  = s.CurrentPlayer();
    const int opp = 1 - cp;

    const int own_material = s.MenOnBoard(cp)  + s.MenToDeploy(cp);
    const int opp_material = s.MenOnBoard(opp) + s.MenToDeploy(opp);

    const int own_mills = MillCount(s, cp);
    const int opp_mills = MillCount(s, opp);

    const int own_mob = ApproxMobility(s, cp);
    const int opp_mob = ApproxMobility(s, opp);

    return 10 * (own_material - opp_material)
         +  3 * (own_mills    - opp_mills)
         +  1 * (own_mob      - opp_mob);
}

// -----------------------------------------------------------------------
// Negamax with alpha-beta pruning.
//
// Conceptually for 2-player zero-sum games; Nine Men's Morris has the
// subtlety that a "capture" is not a change of turn -- the same player
// moves again. We handle this by negating only when the next state has
// a different current_player than the current one.
//
// Returns score from the perspective of s.CurrentPlayer().
// -----------------------------------------------------------------------
namespace {
int Negamax(const State& s, int depth, int alpha, int beta,
            long& nodes_visited) {
    ++nodes_visited;

    if (s.IsTerminal()) {
        const int w = s.Winner();
        if (w == 2) return 0;
        // The player to move *would have been* some player; but terminal
        // means the game has ended. To give the loser a negative score,
        // we check the last player to move. Simpler: rely on EndGame having
        // set Returns properly -- +1 to winner, -1 to loser. Since we need
        // a score from the perspective of the state's "to-move" player,
        // and there's no to-move player, we use the sign convention from
        // the *negamax caller's* perspective. The caller recurses with the
        // convention `score = -Negamax(child)`, so by the time we hit a
        // terminal, the caller expects the score from THEIR perspective.
        // We use the fact that the last move was made by the OPPOSITE of
        // the frozen `current_player_`. In our engine, on terminal we set
        // current_player_ to kTerminalPlayer so we can't rely on it.
        //
        // Workaround: encode terminal score using s.Winner() and the
        // depth-adjusted magnitude, then let the caller negate as usual.
        // Convention: returns are "for player 0". Transform to "for the
        // caller's parent's current player":
        //
        // In practice: the simplest robust thing is to ensure we never
        // recurse into terminal nodes without immediately resolving them
        // with the right sign. See the caller: after ApplyAction, if the
        // child is terminal, we evaluate in the child's frame.
        //
        // Here: we return +kWinScore if Returns()[0] > 0, -kWinScore if
        // < 0 -- but we still need the caller's perspective. Let's use
        // a marker: +kWinScore means "the side that just moved won".
        // That's what the caller expects after negation.
        if (w == 0) return +kWinScore;  // White won
        return +kWinScore;              // Black won -- also "mover won"
    }

    if (depth == 0) {
        return Evaluate(s);
    }

    int buf[256];
    const int n = s.LegalActionsInto(buf);
    if (n == 0) {
        // Shouldn't happen -- non-terminal with no actions implies we
        // missed a stalemate. Treat as loss for side-to-move.
        return -kWinScore;
    }

    int best = -kWinScore - 1;
    const int cur_player = s.CurrentPlayer();

    for (int i = 0; i < n; ++i) {
        State child = s;
        child.ApplyAction(buf[i]);

        int child_score;
        if (child.IsTerminal()) {
            const int w = child.Winner();
            if (w == 2) {
                child_score = 0;
            } else {
                // The side that just moved is `cur_player`.
                // If winner == cur_player => +kWinScore (good for us),
                // else -kWinScore.
                child_score = (w == cur_player) ? +kWinScore : -kWinScore;
                // Depth tie-break: prefer faster wins, slower losses.
                child_score -= (child_score > 0 ?  (100 - depth)
                                                 : -(100 - depth));
            }
        } else if (child.CurrentPlayer() == cur_player) {
            // Same player moves again (we just formed a mill -> capture).
            // Recurse WITHOUT negating.
            child_score = Negamax(child, depth - 1, alpha, beta, nodes_visited);
        } else {
            // Turn switched: standard negamax negation.
            child_score = -Negamax(child, depth - 1, -beta, -alpha, nodes_visited);
        }

        if (child_score > best)  best  = child_score;
        if (best        > alpha) alpha = best;
        if (alpha       >= beta) break;  // alpha-beta cutoff
    }
    return best;
}
}  // namespace

SearchResult MinimaxSearch(const State& s, int depth) {
    if (s.IsTerminal()) {
        return {-1, 0, 0};
    }
    int buf[256];
    const int n = s.LegalActionsInto(buf);
    if (n == 0) return {-1, -kWinScore, 0};

    long nodes = 0;
    int best_action = buf[0];
    int best_score  = -kWinScore - 1;
    int alpha = -kWinScore - 1;
    const int beta = kWinScore + 1;
    const int cur_player = s.CurrentPlayer();

    for (int i = 0; i < n; ++i) {
        State child = s;
        child.ApplyAction(buf[i]);

        int child_score;
        if (child.IsTerminal()) {
            const int w = child.Winner();
            if (w == 2) {
                child_score = 0;
            } else {
                child_score = (w == cur_player) ? +kWinScore : -kWinScore;
                child_score -= (child_score > 0 ?  (100 - depth)
                                                 : -(100 - depth));
            }
        } else if (child.CurrentPlayer() == cur_player) {
            child_score = Negamax(child, depth - 1, alpha, beta, nodes);
        } else {
            child_score = -Negamax(child, depth - 1, -beta, -alpha, nodes);
        }

        if (child_score > best_score) {
            best_score  = child_score;
            best_action = buf[i];
        }
        if (best_score > alpha) alpha = best_score;
    }
    return {best_action, best_score, nodes};
}

double RandomPlayouts(int num_games, uint64_t seed, int* out_lengths) {
    uint64_t rng = seed ? seed : 0xdeadbeefcafebabeULL;
    double sum_returns_p0 = 0.0;
    int buf[256];
    for (int g = 0; g < num_games; ++g) {
        State s;
        int actions = 0;
        while (!s.IsTerminal()) {
            const int n = s.LegalActionsInto(buf);
            // n is guaranteed > 0 in non-terminal states.
            const int pick = static_cast<int>(XorShift64(rng) % static_cast<uint64_t>(n));
            s.ApplyAction(buf[pick]);
            ++actions;
        }
        sum_returns_p0 += s.Returns()[0];
        if (out_lengths) out_lengths[g] = actions;
    }
    return sum_returns_p0;
}

}  // namespace fastnmm
